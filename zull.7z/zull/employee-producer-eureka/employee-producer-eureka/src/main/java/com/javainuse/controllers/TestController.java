package com.javainuse.controllers;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.javainuse.model.Employee;

@RestController
public class TestController {

	@RequestMapping(value = "/employee", method = RequestMethod.GET)
	public Employee firstPage() {

		Employee emp = new Employee();
		emp.setName("emp1");
		emp.setDesignation("manager");
		emp.setEmpId("1");
		emp.setSalary(3000);

		return emp;
	}
	
	@RequestMapping(value = "/addition", method = RequestMethod.GET)
	public int addNum() {

		
		return 1;
	}
	
	@RequestMapping(value = "/subtract", method = RequestMethod.GET)
	public int subNum() {

		
		return 1;
	}
	@RequestMapping(value = "/multiply", method = RequestMethod.GET)
	public int multipNum() {

		
		return 1;
	}
	@RequestMapping(value = "/divide", method = RequestMethod.GET)
	public int divideNum() {

		
		return 1;
	}


}
